create database if not exists ingusbbo_piico;
create user 'ingusbbo_piico'@'%' identified by 'Clt28$2}C]xo';
grant all privileges on ingusbbo_piico.* to ingusbbo_piico with grant option;