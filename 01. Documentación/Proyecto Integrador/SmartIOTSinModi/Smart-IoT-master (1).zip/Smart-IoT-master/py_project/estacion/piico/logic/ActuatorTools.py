'''
Created on 28/02/2020

@author: aasanchez
'''

class MyClass(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        