import paho.mqtt.client as mqtt
import sys
broker_url = "192.168.1.79"
broker_port = 1883


client = mqtt.Client()
client.connect(broker_url, broker_port)
print("ingrese mensaje:")
mensaje = raw_input()
client.publish(topic="Linux", payload = mensaje , qos=0, retain=False)
